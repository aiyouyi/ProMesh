// Copyright Epic Games, Inc. All Rights Reserved.

#include "MakoLibBPLibrary.h"
#include "MakoLib.h"

UMakoLibBPLibrary::UMakoLibBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

float UMakoLibBPLibrary::MakoLibSampleFunction(float Param)
{
	return -1;
}

bool UMakoLibBPLibrary::PointToMeshVertex(const TArray<FVector>& Points, TArray<FVector>& Vextexs, TArray<int32>& Indices)
{
	if (Points.Num()<=2)
	{
		return false;
	}
	Vextexs.Empty();
	Indices.Empty();
	Vextexs.Append(Points);
	int32 PointsNum = Points.Num();
	for (int32 Index = 0; Index < PointsNum; ++Index)
	{
		FVector Point = Points[Index];
		Point.Z -= 100;
		Vextexs.Add(Point);
		if (Index > 0 && Index <= PointsNum - 2)
		{
			Indices.Add(0);
			Indices.Add(Index);
			Indices.Add(Index + 1);

			Indices.Add(PointsNum);
			Indices.Add(PointsNum + Index + 1);
			Indices.Add(PointsNum + Index);
		}
		Indices.Add(Index);
		Indices.Add(PointsNum + Index);
		Indices.Add((Index + 1) % PointsNum);

		Indices.Add((Index + 1) % PointsNum);
		Indices.Add(PointsNum + Index);
		Indices.Add((Index + 1) % PointsNum + PointsNum);
	}
	return true;
}

